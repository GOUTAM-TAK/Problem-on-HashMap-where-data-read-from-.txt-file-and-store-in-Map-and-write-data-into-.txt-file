package petStoreSystem.exception;

@SuppressWarnings("serial")
public class AuthorizationException extends Exception {

	public AuthorizationException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
