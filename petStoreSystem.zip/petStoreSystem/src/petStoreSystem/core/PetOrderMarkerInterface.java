package petStoreSystem.core;

public interface PetOrderMarkerInterface {

}
