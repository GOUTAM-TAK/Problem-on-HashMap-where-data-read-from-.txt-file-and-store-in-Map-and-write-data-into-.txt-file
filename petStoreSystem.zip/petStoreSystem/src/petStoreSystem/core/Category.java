package petStoreSystem.core;

public enum Category {
	 CAT, DOG , RABBIT , FISH, TURTLE, RAT;
	
}
